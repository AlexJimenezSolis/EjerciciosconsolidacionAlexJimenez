a = int(input("introduce el numero:"))
b = int(input("intoduce el segundo numero"))
c = input("introduce la operacion:")

if c == "+":
    print(a+b)
if c == "-":
    print(a-b)
if c == "*":
    print(a * b)
if c == "/":
    print(a / b)
if c == "//":
    print(a // b)
if c == "%":
    print(a % b)

