simbol=""
numero=int(input("de que tamaño quieres la piramide?: "))
print(simbol)
for i in range(numero):
    simbol= simbol + ""
    print(simbol)