while True:
    yeet = (input("introduce 10 numeros:"))

    if yeet == 0:
        print("este numero es par")
    elif (int(yeet)) % 2 == 0:
        print("este numero es par")
    else:
        print("este numero es impar")



