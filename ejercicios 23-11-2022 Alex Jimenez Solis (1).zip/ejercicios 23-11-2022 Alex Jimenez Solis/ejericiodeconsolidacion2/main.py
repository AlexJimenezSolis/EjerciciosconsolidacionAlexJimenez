print("¿Que asignaturas estudio?: ", end="")
assignaturas = input()
print(f"Yo estudio {assignaturas}")